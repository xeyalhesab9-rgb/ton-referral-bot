# TON referral bot on Vercel

Environment variables: BOT_TOKEN, ADMIN_ID, WEBHOOK_SECRET, DATABASE_URL (Supabase PostgreSQL connection string, preferably transaction pooler compatible with serverless).

Deploy GitHub repository to Vercel. Create a Supabase project and copy PostgreSQL connection string (use SSL as required). Set Vercel environment variables and redeploy.

Set webhook in a browser or terminal (do not share the URL containing your token):

`https://api.telegram.org/bot<BOT_TOKEN>/setWebhook?url=https%3A%2F%2F<YOUR_DOMAIN>%2Ftelegram&secret_token=<WEBHOOK_SECRET>`

Use a random secret of 32+ letters/numbers/underscores/dashes. Never commit secrets to GitHub.

This is a prototype, not a production payment system. Referrals require manual approval; balances are internal liabilities, not on-chain funds. /paid only records an externally completed payment. Verify wallet, amount and on-chain transaction before marking paid. No automatic transfers. Consider identity checks, fraud prevention, rate limits, DB backups, and idempotent update processing before real-money launch. Vercel Hobby is intended for non-commercial personal use, so confirm your use is allowed.
