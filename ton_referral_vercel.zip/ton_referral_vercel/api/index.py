import os
import hmac
from decimal import Decimal
from flask import Flask, request, abort
import requests
import psycopg

app = Flask(__name__)
TOKEN = os.environ['BOT_TOKEN']
SECRET = os.environ['WEBHOOK_SECRET']
ADMIN_ID = int(os.environ['ADMIN_ID'])
DB = os.environ['DATABASE_URL']
API = f'https://api.telegram.org/bot{TOKEN}/'
REWARD = Decimal('0.01')
MIN_WITHDRAW = Decimal('0.10')

def conn():
    return psycopg.connect(DB, autocommit=False)

def send(chat, msg):
    requests.post(API+'sendMessage', json={'chat_id':chat,'text':msg}, timeout=7).raise_for_status()

def init_db():
    with conn() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS users (id BIGINT PRIMARY KEY, inviter BIGINT REFERENCES users(id), balance NUMERIC(18,9) NOT NULL DEFAULT 0, referrals INTEGER NOT NULL DEFAULT 0, wallet TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS withdrawals (id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id), amount NUMERIC(18,9) NOT NULL, wallet TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at TIMESTAMPTZ DEFAULT NOW())''')

def handler(uid, text):
    cmd, *rest = text.strip().split(maxsplit=1)
    arg = rest[0].strip() if rest else ''
    if cmd == '/start':
        inviter = None
        if arg.startswith('ref_'):
            try: inviter = int(arg[4:])
            except ValueError: pass
        with conn() as c:
            exists = c.execute('SELECT 1 FROM users WHERE id=%s', (uid,)).fetchone()
            if not exists:
                valid = inviter and inviter != uid and c.execute('SELECT 1 FROM users WHERE id=%s',(inviter,)).fetchone()
                c.execute('INSERT INTO users(id, inviter) VALUES (%s,%s)', (uid, inviter if valid else None))
                if valid:
                    send(ADMIN_ID, f'Yeni referal: {uid}, dəvət edən: {inviter}. Təsdiq: /approve_ref {uid}')
        send(uid, 'Xoş gəldin! /link /balance /wallet /withdraw /help')
    elif cmd == '/help':
        send(uid, '/link - referal linki\n/balance - balans\n/wallet UQ... - TON ünvanını qeyd et\n/withdraw - çıxarış istə\nAdmin: /approve_ref ID, /reject_ref ID, /paid ID, /reject_withdraw ID')
    elif cmd == '/link':
        username = requests.get(API+'getMe', timeout=7).json()['result']['username']
        send(uid, f'Referal linkin: https://t.me/{username}?start=ref_{uid}\nBonus: hər admin təsdiqli dəvət üçün {REWARD} TON')
    elif cmd == '/balance':
        with conn() as c:
            r=c.execute('SELECT balance, referrals FROM users WHERE id=%s',(uid,)).fetchone()
        send(uid, f'Balans: {r[0]} TON\nTəsdiqlənmiş referal: {r[1]}' if r else 'Əvvəl /start yaz.')
    elif cmd == '/wallet':
        if not (arg.startswith(('UQ','EQ')) and len(arg)==48):
            return send(uid,'TON ünvanını belə daxil et: /wallet UQ... (48 simvol)')
        with conn() as c:
            c.execute('UPDATE users SET wallet=%s WHERE id=%s',(arg,uid))
        send(uid,'TON ünvanı saxlandı. Göndərməzdən əvvəl ünvanı yoxla.')
    elif cmd == '/withdraw':
        with conn() as c:
            row=c.execute('SELECT balance,wallet FROM users WHERE id=%s FOR UPDATE',(uid,)).fetchone()
            if not row: return send(uid,'Əvvəl /start yaz.')
            bal,wallet=row
            if not wallet: return send(uid,'Əvvəl /wallet UQ... ilə ünvan daxil et.')
            if bal < MIN_WITHDRAW: return send(uid,f'Minimum çıxarış {MIN_WITHDRAW} TON. Balans: {bal}')
            c.execute('UPDATE users SET balance=balance-%s WHERE id=%s',(bal,uid))
            wid=c.execute('INSERT INTO withdrawals(user_id,amount,wallet) VALUES (%s,%s,%s) RETURNING id',(uid,bal,wallet)).fetchone()[0]
        send(uid,f'Çıxarış #{wid} gözləmədədir: {bal} TON')
        send(ADMIN_ID,f'Çıxarış #{wid}: {uid}, {bal} TON, ünvan: {wallet}\nÖdənişi özün etdikdən sonra /paid {wid}\nRədd: /reject_withdraw {wid}')
    elif cmd in ('/approve_ref','/reject_ref','/paid','/reject_withdraw'):
        if uid != ADMIN_ID: return send(uid,'İcazə yoxdur.')
        try: target=int(arg)
        except ValueError: return send(uid,'Düzgün ID daxil et.')
        if cmd in ('/approve_ref','/reject_ref'):
            with conn() as c:
                c.execute('''CREATE TABLE IF NOT EXISTS referral_reviews (referred_id BIGINT PRIMARY KEY REFERENCES users(id), status TEXT NOT NULL)''')
                r=c.execute('SELECT inviter FROM users WHERE id=%s',(target,)).fetchone()
                if not r or not r[0]: return send(uid,'Bu ID üçün referal yoxdur.')
                status='approved' if cmd=='/approve_ref' else 'rejected'
                changed=c.execute('INSERT INTO referral_reviews(referred_id,status) VALUES (%s,%s) ON CONFLICT DO NOTHING RETURNING referred_id',(target,status)).fetchone()
                if not changed: return send(uid,'Bu referal artıq yoxlanılıb.')
                if status=='approved':
                    c.execute('UPDATE users SET balance=balance+%s, referrals=referrals+1 WHERE id=%s',(REWARD,r[0]))
            send(uid,f'Referal {target}: {status}')
            if status=='approved': send(r[0],f'Referal təsdiqləndi! +{REWARD} TON')
        else:
            status='paid' if cmd=='/paid' else 'rejected'
            with conn() as c:
                r=c.execute("UPDATE withdrawals SET status=%s WHERE id=%s AND status='pending' RETURNING user_id,amount",(status,target)).fetchone()
                if not r: return send(uid,'Çıxarış tapılmadı və ya artıq bağlanıb.')
                if status=='rejected': c.execute('UPDATE users SET balance=balance+%s WHERE id=%s',(r[1],r[0]))
            send(uid,f'Çıxarış #{target}: {status}')
            send(r[0],f'Çıxarış #{target}: {status}')
    else:
        send(uid,'Əmrlər üçün /help yaz.')

@app.post('/api/index')
def webhook():
    if not hmac.compare_digest(request.headers.get('X-Telegram-Bot-Api-Secret-Token',''),SECRET): abort(403)
    data=request.get_json(silent=True) or {}
    msg=data.get('message') or {}
    if msg.get('text') and msg.get('from',{}).get('id'):
        try:
            init_db()
            handler(int(msg['from']['id']),msg['text'])
        except Exception:
            app.logger.exception('Telegram update failed')
            return 'error',500
    return 'ok',200
